"use client"

import  from "../src/routes/__root"

export default function SyntheticV0PageForDeployment() {
  return < />
}