import { useRouterState } from "@tanstack/react-router";
import { Atom, ChevronLeft, FlaskConical, LayoutDashboard, ListTodo, Server, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

const nav = [
  { title: "Overview", url: "/", icon: LayoutDashboard },
  { title: "Evidence Ledger", url: "/evidence", icon: ShieldCheck, count: 3 },
  { title: "Physics Runs", url: "/runs", icon: Atom },
  { title: "Tasks", url: "/tasks", icon: ListTodo, count: 5 },
  { title: "Jobs", url: "/jobs", icon: Server },
];

export function AppSidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const pathname = useRouterState({ select: s => s.location.pathname });
  return <aside className={cn("sticky top-0 hidden h-screen shrink-0 flex-col border-r border-sidebar-border bg-sidebar/95 transition-[width] duration-300 lg:flex", collapsed ? "w-[72px]" : "w-60")}>
    <div className="flex h-16 items-center gap-3 border-b border-sidebar-border px-4"><div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-primary/40 bg-primary/10 text-primary shadow-[0_0_18px_-6px_var(--cyan-brand)]"><FlaskConical className="h-5 w-5"/></div>{!collapsed && <div className="min-w-0"><div className="font-semibold tracking-tight">AiSci</div><div className="truncate text-[9px] uppercase tracking-[0.18em] text-muted-foreground">Research control plane</div></div>}</div>
    <div className="px-3 py-4">{!collapsed && <div className="mb-3 text-[9px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">Navigation</div>}<nav className="flex flex-col gap-1">{nav.map(item => { const active = item.url === "/" ? pathname === "/" : pathname.startsWith(item.url); return <a key={item.title} href={item.url} title={item.title} className={cn("relative flex h-10 items-center gap-3 rounded-md px-3 text-sm transition-colors", active ? "bg-sidebar-accent text-foreground before:absolute before:-left-3 before:h-5 before:w-0.5 before:bg-primary" : "text-muted-foreground hover:bg-sidebar-accent/60 hover:text-foreground")}><item.icon className={cn("h-4 w-4 shrink-0", active && "text-primary")}/>{!collapsed && <><span className="flex-1">{item.title}</span>{item.count && <span className="rounded bg-primary/10 px-1.5 py-0.5 font-mono text-[10px] text-primary">{item.count}</span>}</>}</a>})}</nav></div>
    <div className="mt-auto border-t border-sidebar-border p-3"><div className={cn("flex items-center gap-2", collapsed && "justify-center")}><div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-violet-brand/15 text-[10px] font-semibold text-violet-brand">RB</div>{!collapsed && <div className="min-w-0 flex-1"><div className="truncate text-xs font-medium">R. Boltzmann</div><div className="truncate text-[9px] text-muted-foreground">Principal investigator</div></div>}<button onClick={() => setCollapsed(v => !v)} aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"} className="rounded-md p-2 text-muted-foreground hover:bg-secondary hover:text-foreground"><ChevronLeft className={cn("h-4 w-4 transition", collapsed && "rotate-180")}/></button></div></div>
  </aside>;
}
