// Mock physics research control-plane data layer.
// All functions return Promises so they can be consumed directly by @tanstack/react-query.

export type TaskStatus = "pending" | "running" | "anomaly" | "success";
export type JobStatus = "queued" | "running" | "anomaly" | "success";

export interface AgentSummary {
  id: string;
  name: string;
  role: string;
  status: "active" | "idle" | "blocked";
  load: number; // 0-100
  throughput: string;
}

export interface SyncStatus {
  database: string;
  state: "synced" | "syncing" | "degraded";
  progress: number;
  lastSync: string;
  records: number;
  latencyMs: number;
}

export interface Anomaly {
  id: string;
  title: string;
  observable: string;
  severity: "low" | "medium" | "high";
  sigma: number;
  detectedAt: string;
}

export interface ActivityItem {
  id: string;
  agent: string;
  action: string;
  detail: string;
  kind: "ingest" | "fit" | "evidence" | "anomaly" | "job";
  timestamp: string;
}

export interface Metric {
  label: string;
  value: string;
  delta: number;
  unit?: string;
  spark: number[];
  accent: "cyan" | "amber" | "emerald" | "violet";
}

export interface LogLine {
  t: string;
  level: "info" | "warn" | "error" | "debug";
  msg: string;
}

export interface Task {
  id: string;
  title: string;
  dataset: string;
  status: TaskStatus;
  progress: number;
  agent: string;
  priority: "P0" | "P1" | "P2";
  updatedAt: string;
  provenance: {
    source: string;
    doi: string;
    checksum: string;
    ingestedRows: number;
    pipeline: string;
  };
  logs: LogLine[];
}

export interface Job {
  id: string;
  name: string;
  model: string;
  status: JobStatus;
  progress: number;
  observable: string;
  chiSq: number;
  ndf: number;
  gpuHours: number;
  eta: string;
  agent: string;
  provenance: {
    commit: string;
    solver: string;
    dataset: string;
    walltime: string;
  };
  logs: LogLine[];
}

export interface Claim {
  id: string;
  statement: string;
  observable: string;
  model: string;
  confidence: number; // 0-1
  status: "corroborated" | "under-review" | "contested";
  citations: number;
  parameters: { name: string; value: string; unc: string }[];
  fit: { x: number; data: number; model: number }[];
  residuals: { x: number; r: number }[];
  contour: { x: number; y: number }[];
}

export interface PhysicsRun {
  id: string;
  label: string;
  system: string;
  energy: string;
  status: JobStatus;
  progress: number;
  events: string;
  temperature: number;
  qParam: number;
}

const now = Date.now();
const iso = (minAgo: number) => new Date(now - minAgo * 60_000).toISOString();

/* ----------------------------------- OVERVIEW ---------------------------------- */

export function fetchMetrics(): Promise<Metric[]> {
  return Promise.resolve([
    {
      label: "Active Agents",
      value: "7",
      delta: 16.7,
      spark: [3, 4, 4, 5, 6, 6, 7],
      accent: "cyan",
    },
    {
      label: "Physics Jobs Running",
      value: "12",
      delta: 9.1,
      spark: [8, 9, 7, 10, 11, 12, 12],
      accent: "violet",
    },
    {
      label: "Mean Fit χ²/ndf",
      value: "1.07",
      delta: -4.3,
      spark: [1.3, 1.24, 1.19, 1.15, 1.11, 1.09, 1.07],
      accent: "emerald",
    },
    {
      label: "Open Anomalies",
      value: "3",
      delta: 50,
      spark: [1, 1, 2, 2, 2, 3, 3],
      accent: "amber",
    },
  ]);
}

export function fetchAgents(): Promise<AgentSummary[]> {
  return Promise.resolve([
    { id: "AGT-01", name: "Ingestor", role: "Literature intake", status: "active", load: 72, throughput: "48 docs/min" },
    { id: "AGT-02", name: "Fitter", role: "Tsallis / Boltzmann fits", status: "active", load: 88, throughput: "6 fits/min" },
    { id: "AGT-03", name: "Validator", role: "Symbolic validation", status: "active", load: 41, throughput: "12 checks/min" },
    { id: "AGT-04", name: "Anomaly Scout", role: "Residual scanning", status: "blocked", load: 12, throughput: "stalled" },
    { id: "AGT-05", name: "Archivist", role: "Evidence ledger", status: "idle", load: 4, throughput: "0 writes/min" },
  ]);
}

export function fetchSyncStatus(): Promise<SyncStatus> {
  return Promise.resolve({
    database: "aisci-hep-primary",
    state: "syncing",
    progress: 73,
    lastSync: iso(2),
    records: 2_481_930,
    latencyMs: 41,
  });
}

export function fetchAnomalies(): Promise<Anomaly[]> {
  return Promise.resolve([
    { id: "ANM-118", title: "Excess in high-pT tail", observable: "1/pT dN/dpT", severity: "high", sigma: 4.2, detectedAt: iso(14) },
    { id: "ANM-117", title: "Residual drift near T_kin", observable: "Tsallis T", severity: "medium", sigma: 2.7, detectedAt: iso(63) },
    { id: "ANM-115", title: "q-parameter instability", observable: "q(√s)", severity: "low", sigma: 1.9, detectedAt: iso(140) },
  ]);
}

export function fetchActivityFeed(): Promise<ActivityItem[]> {
  return Promise.resolve([
    { id: "a1", agent: "Fitter", action: "Converged fit", detail: "Tsallis fit on Pb-Pb 5.02 TeV reached χ²/ndf = 1.03", kind: "fit", timestamp: iso(1) },
    { id: "a2", agent: "Anomaly Scout", action: "Flagged anomaly", detail: "4.2σ excess in high-pT spectrum ANM-118", kind: "anomaly", timestamp: iso(4) },
    { id: "a3", agent: "Ingestor", action: "Ingested dataset", detail: "arXiv:2405.11872 — 18,204 spectral points", kind: "ingest", timestamp: iso(9) },
    { id: "a4", agent: "Archivist", action: "Sealed claim", detail: "Claim CLM-204 corroborated at 0.94 confidence", kind: "evidence", timestamp: iso(17) },
    { id: "a5", agent: "Fitter", action: "Job dispatched", detail: "Jüttner derivation JOB-77 sent to GPU pool", kind: "job", timestamp: iso(23) },
    { id: "a6", agent: "Validator", action: "Symbolic check", detail: "Verified dimensional consistency of parametrization", kind: "fit", timestamp: iso(31) },
  ]);
}

/* ------------------------------------ TASKS ------------------------------------ */

export function fetchTasks(): Promise<Task[]> {
  return Promise.resolve([
    {
      id: "TSK-3201",
      title: "Ingest ALICE pT spectra",
      dataset: "Pb-Pb √sNN = 5.02 TeV",
      status: "running",
      progress: 64,
      agent: "Ingestor",
      priority: "P0",
      updatedAt: iso(1),
      provenance: { source: "arXiv:2405.11872", doi: "10.1103/PhysRevC.109.024901", checksum: "sha256:9f2a…c41b", ingestedRows: 18204, pipeline: "hep-intake@v3" },
      logs: [
        { t: "00:00:01", level: "info", msg: "Pulled 42 tables from source PDF" },
        { t: "00:00:07", level: "info", msg: "Normalized transverse momentum bins to GeV/c" },
        { t: "00:00:12", level: "warn", msg: "3 bins missing systematic uncertainty — imputed" },
      ],
    },
    {
      id: "TSK-3200",
      title: "Extract Tsallis parameters",
      dataset: "p-p √s = 13 TeV",
      status: "success",
      progress: 100,
      agent: "Fitter",
      priority: "P1",
      updatedAt: iso(12),
      provenance: { source: "arXiv:2312.00234", doi: "10.1016/j.physletb.2023.138190", checksum: "sha256:11de…7a02", ingestedRows: 9640, pipeline: "fit-extract@v2" },
      logs: [
        { t: "00:00:02", level: "info", msg: "Loaded 9,640 spectral points" },
        { t: "00:00:18", level: "info", msg: "Tsallis-Levy fit converged, q = 1.121 ± 0.004" },
        { t: "00:00:19", level: "debug", msg: "Wrote parameters to evidence ledger" },
      ],
    },
    {
      id: "TSK-3199",
      title: "Reconcile systematic uncertainties",
      dataset: "Xe-Xe √sNN = 5.44 TeV",
      status: "anomaly",
      progress: 88,
      agent: "Anomaly Scout",
      priority: "P0",
      updatedAt: iso(5),
      provenance: { source: "arXiv:2401.55210", doi: "10.1140/epjc/s10052-024-12345", checksum: "sha256:aa41…9b0f", ingestedRows: 12880, pipeline: "recon@v1" },
      logs: [
        { t: "00:00:04", level: "info", msg: "Cross-checking against 3 reference datasets" },
        { t: "00:00:22", level: "error", msg: "4.2σ deviation detected in high-pT tail" },
        { t: "00:00:22", level: "warn", msg: "Raised anomaly ANM-118 for review" },
      ],
    },
    {
      id: "TSK-3198",
      title: "Queue Jüttner derivation",
      dataset: "Au-Au √sNN = 200 GeV",
      status: "pending",
      progress: 0,
      agent: "Fitter",
      priority: "P2",
      updatedAt: iso(28),
      provenance: { source: "arXiv:2310.09981", doi: "10.1103/PhysRevLett.131.202301", checksum: "sha256:5c7e…d3aa", ingestedRows: 0, pipeline: "symbolic@v2" },
      logs: [{ t: "00:00:00", level: "info", msg: "Task scheduled, awaiting GPU allocation" }],
    },
    {
      id: "TSK-3197",
      title: "Normalize rapidity windows",
      dataset: "p-Pb √sNN = 8.16 TeV",
      status: "running",
      progress: 37,
      agent: "Ingestor",
      priority: "P1",
      updatedAt: iso(3),
      provenance: { source: "arXiv:2402.31007", doi: "10.1007/JHEP04(2024)118", checksum: "sha256:e0b2…41cc", ingestedRows: 7420, pipeline: "hep-intake@v3" },
      logs: [
        { t: "00:00:03", level: "info", msg: "Detected 6 rapidity windows" },
        { t: "00:00:09", level: "info", msg: "Rebinning to common |y| < 0.5 acceptance" },
      ],
    },
  ]);
}

/* ------------------------------------ JOBS ------------------------------------- */

export function fetchJobs(): Promise<Job[]> {
  return Promise.resolve([
    {
      id: "JOB-77",
      name: "Jüttner relativistic derivation",
      model: "Maxwell-Jüttner",
      status: "running",
      progress: 58,
      observable: "f(p) momentum distribution",
      chiSq: 41.2,
      ndf: 38,
      gpuHours: 12.4,
      eta: "~9 min",
      agent: "Fitter",
      provenance: { commit: "a91f4c2", solver: "MINUIT2 / MIGRAD", dataset: "Au-Au 200 GeV", walltime: "01:42:11" },
      logs: [
        { t: "01:40:02", level: "info", msg: "Gradient descent iteration 2,140" },
        { t: "01:41:55", level: "info", msg: "EDM = 3.1e-05, approaching tolerance" },
      ],
    },
    {
      id: "JOB-76",
      name: "Tsallis global fit sweep",
      model: "Tsallis-Levy",
      status: "success",
      progress: 100,
      observable: "1/pT dN/dpT",
      chiSq: 39.4,
      ndf: 41,
      gpuHours: 8.1,
      eta: "done",
      agent: "Fitter",
      provenance: { commit: "7d0be19", solver: "L-BFGS-B", dataset: "p-p 13 TeV", walltime: "00:58:03" },
      logs: [
        { t: "00:57:40", level: "info", msg: "Converged: q = 1.121, T = 0.084 GeV" },
        { t: "00:58:03", level: "debug", msg: "Persisted 41 parameter posteriors" },
      ],
    },
    {
      id: "JOB-75",
      name: "Residual contour scan",
      model: "Boltzmann-Gibbs",
      status: "anomaly",
      progress: 92,
      observable: "χ² landscape (T, q)",
      chiSq: 88.7,
      ndf: 40,
      gpuHours: 15.9,
      eta: "review",
      agent: "Anomaly Scout",
      provenance: { commit: "c22a0f8", solver: "Nested Sampling", dataset: "Xe-Xe 5.44 TeV", walltime: "02:11:47" },
      logs: [
        { t: "02:10:30", level: "warn", msg: "Bimodal posterior detected in q" },
        { t: "02:11:47", level: "error", msg: "χ²/ndf = 2.22 exceeds 2σ gate" },
      ],
    },
    {
      id: "JOB-74",
      name: "Freeze-out temperature extraction",
      model: "Blast-Wave",
      status: "queued",
      progress: 0,
      observable: "T_kin, ⟨βT⟩",
      chiSq: 0,
      ndf: 44,
      gpuHours: 0,
      eta: "queued",
      agent: "Fitter",
      provenance: { commit: "e5519ac", solver: "MCMC / emcee", dataset: "Pb-Pb 5.02 TeV", walltime: "00:00:00" },
      logs: [{ t: "00:00:00", level: "info", msg: "Awaiting GPU pool slot (position 2)" }],
    },
  ]);
}

/* ------------------------------------ RUNS ------------------------------------- */

export function fetchRuns(): Promise<PhysicsRun[]> {
  return Promise.resolve([
    { id: "RUN-5021", label: "Pb-Pb central", system: "Pb-Pb", energy: "5.02 TeV", status: "running", progress: 61, events: "3.2M", temperature: 0.084, qParam: 1.121 },
    { id: "RUN-1300", label: "p-p minbias", system: "p-p", energy: "13 TeV", status: "success", progress: 100, events: "8.7M", temperature: 0.072, qParam: 1.148 },
    { id: "RUN-0200", label: "Au-Au RHIC", system: "Au-Au", energy: "200 GeV", status: "queued", progress: 0, events: "1.1M", temperature: 0.089, qParam: 1.104 },
    { id: "RUN-0544", label: "Xe-Xe scan", system: "Xe-Xe", energy: "5.44 TeV", status: "anomaly", progress: 92, events: "2.4M", temperature: 0.081, qParam: 1.133 },
  ]);
}

/* ----------------------------------- EVIDENCE ---------------------------------- */

function makeFit(seed: number, T: number, q: number) {
  const fit = [];
  const residuals = [];
  for (let i = 0; i < 22; i++) {
    const x = 0.2 + i * 0.45; // pT in GeV/c
    const model = 12000 * Math.pow(1 + ((q - 1) * x) / T, -1 / (q - 1));
    const noise = 1 + (Math.sin(i * seed) * 0.06);
    const data = model * noise;
    fit.push({ x: +x.toFixed(2), data: +data.toFixed(1), model: +model.toFixed(1) });
    residuals.push({ x: +x.toFixed(2), r: +(((data - model) / (model * 0.03))).toFixed(2) });
  }
  return { fit, residuals };
}

function makeContour(cx: number, cy: number) {
  const pts = [];
  for (let a = 0; a <= 360; a += 20) {
    const rad = (a * Math.PI) / 180;
    pts.push({
      x: +(cx + 0.006 * Math.cos(rad)).toFixed(4),
      y: +(cy + 0.02 * Math.sin(rad) + 0.004 * Math.cos(rad)).toFixed(4),
    });
  }
  return pts;
}

export function fetchClaims(): Promise<Claim[]> {
  const c1 = makeFit(1.3, 0.084, 1.121);
  const c2 = makeFit(0.7, 0.072, 1.148);
  const c3 = makeFit(2.1, 0.081, 1.133);
  return Promise.resolve([
    {
      id: "CLM-204",
      statement: "Transverse momentum spectra in Pb-Pb follow a Tsallis distribution with q = 1.121 ± 0.004.",
      observable: "1/pT dN/dpT",
      model: "Tsallis-Levy",
      confidence: 0.94,
      status: "corroborated",
      citations: 12,
      parameters: [
        { name: "q", value: "1.121", unc: "± 0.004" },
        { name: "T", value: "0.084 GeV", unc: "± 0.002" },
        { name: "χ²/ndf", value: "1.03", unc: "" },
      ],
      fit: c1.fit,
      residuals: c1.residuals,
      contour: makeContour(1.121, 0.084),
    },
    {
      id: "CLM-203",
      statement: "p-p collisions at 13 TeV exhibit a non-extensive parameter consistent with q = 1.148.",
      observable: "1/pT dN/dpT",
      model: "Tsallis-Levy",
      confidence: 0.81,
      status: "under-review",
      citations: 7,
      parameters: [
        { name: "q", value: "1.148", unc: "± 0.006" },
        { name: "T", value: "0.072 GeV", unc: "± 0.003" },
        { name: "χ²/ndf", value: "1.12", unc: "" },
      ],
      fit: c2.fit,
      residuals: c2.residuals,
      contour: makeContour(1.148, 0.072),
    },
    {
      id: "CLM-201",
      statement: "Xe-Xe high-pT tail deviates from Boltzmann-Gibbs expectation at 4.2σ.",
      observable: "high-pT residual",
      model: "Boltzmann-Gibbs",
      confidence: 0.42,
      status: "contested",
      citations: 3,
      parameters: [
        { name: "q", value: "1.133", unc: "± 0.009" },
        { name: "T", value: "0.081 GeV", unc: "± 0.004" },
        { name: "χ²/ndf", value: "2.22", unc: "" },
      ],
      fit: c3.fit,
      residuals: c3.residuals,
      contour: makeContour(1.133, 0.081),
    },
  ]);
}

/* ----------------------------------- ACTIONS ----------------------------------- */

export function runSync(): Promise<{ message: string }> {
  return new Promise((resolve) =>
    setTimeout(() => resolve({ message: "Synced 2,481,930 records across 4 physics runs." }), 1400),
  );
}
