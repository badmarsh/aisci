// Minimal server-rendered fallback used by the SSR error middleware.
export function renderErrorPage() {
  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>AiSci — Server Error</title>
    <style>
      body { margin:0; font-family: ui-sans-serif, system-ui, sans-serif; background:#09090b; color:#fafafa;
        display:flex; min-height:100vh; align-items:center; justify-content:center; }
      .box { text-align:center; max-width:32rem; padding:2rem; }
      h1 { font-size:1.25rem; font-weight:600; margin:0 0 .5rem; }
      p { color:#a1a1aa; font-size:.875rem; }
      a { color:#22d3ee; text-decoration:none; }
    </style>
  </head>
  <body>
    <div class="box">
      <h1>The AiSci control plane hit a server error</h1>
      <p>The request could not be completed. <a href="/">Return to overview</a></p>
    </div>
  </body>
</html>`;
}
