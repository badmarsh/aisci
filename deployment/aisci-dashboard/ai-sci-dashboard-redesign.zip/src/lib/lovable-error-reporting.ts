// Lightweight client error reporter. In production this could forward to an
// observability sink; here it logs with a namespaced prefix for debugging.
export function reportLovableError(error: unknown, context?: Record<string, unknown>) {
  console.error("[v0] app-error", error, context ?? {});
}
