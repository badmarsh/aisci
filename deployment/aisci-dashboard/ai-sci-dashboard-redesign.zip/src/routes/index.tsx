import type { ReactNode } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Area, AreaChart, CartesianGrid, Line, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Activity, AlertTriangle, ArrowUpRight, Bot, CheckCircle2, Database, Radio, Sigma } from "lucide-react";
import { fetchActivityFeed, fetchAgents, fetchAnomalies, fetchMetrics, fetchSyncStatus } from "@/lib/api";
import { MetricCard } from "@/components/dashboard/MetricCard";
import { PageShell } from "@/components/PageShell";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [{ title: "Overview — AiSci" }, { name: "description", content: "AiSci autonomous physics research control plane" }] }),
  component: Overview,
});

const fitData = [
  { t: "08:00", fits: 18, accepted: 14 }, { t: "09:00", fits: 24, accepted: 19 },
  { t: "10:00", fits: 21, accepted: 18 }, { t: "11:00", fits: 34, accepted: 28 },
  { t: "12:00", fits: 31, accepted: 27 }, { t: "13:00", fits: 45, accepted: 39 },
  { t: "14:00", fits: 52, accepted: 44 }, { t: "15:00", fits: 48, accepted: 43 },
];

function Overview() {
  const metrics = useQuery({ queryKey: ["metrics"], queryFn: fetchMetrics });
  const agents = useQuery({ queryKey: ["agents"], queryFn: fetchAgents });
  const sync = useQuery({ queryKey: ["sync"], queryFn: fetchSyncStatus });
  const anomalies = useQuery({ queryKey: ["anomalies"], queryFn: fetchAnomalies });
  const activity = useQuery({ queryKey: ["activity"], queryFn: fetchActivityFeed });
  const loading = metrics.isLoading || agents.isLoading || sync.isLoading;

  return (
    <PageShell>
      <section className="mb-6 flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-[0.18em] text-primary"><Radio className="h-3.5 w-3.5" /> Live research fabric</div>
          <h1 className="text-balance text-3xl font-semibold tracking-tight md:text-4xl">Scientific operations overview</h1>
          <p className="max-w-2xl text-pretty text-sm leading-6 text-muted-foreground">Autonomous agents are ingesting evidence, fitting collision spectra, and validating physical claims across the active research graph.</p>
        </div>
        <div className="flex items-center gap-3 border-l border-primary/40 pl-4">
          <div><div className="font-mono text-xl font-semibold">5.02 TeV</div><div className="text-xs text-muted-foreground">Pb–Pb active frame</div></div>
          <div className="h-8 w-px bg-border" /><div><div className="font-mono text-xl font-semibold text-emerald-brand">99.98%</div><div className="text-xs text-muted-foreground">pipeline uptime</div></div>
        </div>
      </section>

      {loading ? <div className="h-80 animate-pulse rounded-xl border border-border bg-card" /> : <>
        <section aria-label="Research metrics" className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          {metrics.data?.map((metric) => <MetricCard key={metric.label} metric={metric} />)}
        </section>

        <section className="mt-4 grid gap-4 xl:grid-cols-12">
          <Panel className="xl:col-span-7" title="Fit throughput" label="Accepted model fits / hour" icon={Sigma} action="Last 8 hours">
            <div className="mt-4 h-72" aria-label="Chart showing submitted and accepted model fits over eight hours">
              <ResponsiveContainer width="100%" height="100%"><AreaChart data={fitData} margin={{ top: 8, right: 8, left: -24, bottom: 0 }}>
                <defs><linearGradient id="fit-fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="var(--cyan-brand)" stopOpacity={0.28}/><stop offset="100%" stopColor="var(--cyan-brand)" stopOpacity={0}/></linearGradient></defs>
                <CartesianGrid stroke="var(--border)" strokeDasharray="3 5" vertical={false}/><XAxis dataKey="t" tick={{ fill: "var(--muted-foreground)", fontSize: 10 }} axisLine={false} tickLine={false}/><YAxis tick={{ fill: "var(--muted-foreground)", fontSize: 10 }} axisLine={false} tickLine={false}/>
                <Tooltip contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 12 }}/><Area type="monotone" dataKey="accepted" stroke="var(--cyan-brand)" fill="url(#fit-fill)" strokeWidth={2}/><Line type="monotone" dataKey="fits" stroke="var(--violet-brand)" strokeWidth={1.5} dot={false}/>
              </AreaChart></ResponsiveContainer>
            </div>
            <div className="flex gap-5 border-t border-border pt-3 text-xs text-muted-foreground"><span className="flex items-center gap-2"><i className="h-1.5 w-4 bg-primary"/>Accepted</span><span className="flex items-center gap-2"><i className="h-1.5 w-4 bg-violet-brand"/>Submitted</span><span className="ml-auto font-mono text-foreground">χ²/ndf median 1.07</span></div>
          </Panel>

          <Panel className="xl:col-span-5" title="Agent workload" label="Distributed cognition mesh" icon={Bot} action={`${agents.data?.filter(a => a.status === "active").length} active`}>
            <div className="mt-3 flex flex-col divide-y divide-border">
              {agents.data?.map((agent) => <div key={agent.id} className="flex items-center gap-3 py-3">
                <span className={cn("h-2 w-2 rounded-full", agent.status === "active" ? "bg-emerald-brand" : agent.status === "blocked" ? "bg-amber-brand" : "bg-muted-foreground")} />
                <div className="min-w-0 flex-1"><div className="flex justify-between gap-3"><span className="text-sm font-medium">{agent.name}</span><span className="font-mono text-[11px] text-muted-foreground">{agent.load}%</span></div><div className="mt-1.5 h-1 overflow-hidden rounded-full bg-secondary"><div className="h-full bg-primary transition-all" style={{ width: `${agent.load}%` }} /></div><div className="mt-1 flex justify-between text-[10px] text-muted-foreground"><span>{agent.role}</span><span>{agent.throughput}</span></div></div>
              </div>)}
            </div>
          </Panel>

          <Panel className="xl:col-span-4" title="Database sync" label={sync.data?.database ?? "Primary ledger"} icon={Database} action={sync.data?.state ?? "syncing"}>
            <div className="mt-5 flex items-end justify-between"><strong className="font-mono text-4xl font-medium">{sync.data?.progress}%</strong><span className="text-xs text-muted-foreground">{sync.data?.records.toLocaleString()} records</span></div>
            <div className="mt-4 h-2 overflow-hidden rounded-full bg-secondary"><div className="h-full bg-primary shadow-[0_0_12px_var(--cyan-brand)]" style={{ width: `${sync.data?.progress ?? 0}%` }} /></div>
            <dl className="mt-5 grid grid-cols-2 gap-3 border-t border-border pt-4 text-xs"><div><dt className="text-muted-foreground">Read latency</dt><dd className="mt-1 font-mono text-foreground">{sync.data?.latencyMs} ms</dd></div><div><dt className="text-muted-foreground">Replica state</dt><dd className="mt-1 flex items-center gap-1.5 text-emerald-brand"><CheckCircle2 className="h-3 w-3"/>Consistent</dd></div></dl>
          </Panel>

          <Panel className="xl:col-span-4" title="Anomaly queue" label="Residual scan deviations" icon={AlertTriangle} action={`${anomalies.data?.length ?? 0} open`}>
            <div className="mt-3 flex flex-col divide-y divide-border">{anomalies.data?.map(a => <div key={a.id} className="group flex items-center gap-3 py-3"><div className={cn("flex h-8 w-8 items-center justify-center rounded-md font-mono text-xs", a.severity === "high" ? "bg-amber-brand/15 text-amber-brand" : "bg-secondary text-muted-foreground")}>{a.sigma}σ</div><div className="min-w-0 flex-1"><div className="truncate text-sm font-medium">{a.title}</div><div className="font-mono text-[10px] text-muted-foreground">{a.id} · {a.observable}</div></div><ArrowUpRight className="h-4 w-4 text-muted-foreground transition group-hover:text-primary"/></div>)}</div>
          </Panel>

          <Panel className="xl:col-span-4" title="Activity stream" label="Latest agent events" icon={Activity} action="Live">
            <div className="mt-3 flex max-h-64 flex-col overflow-auto scroll-slim">{activity.data?.slice(0,5).map((item, index) => <div key={item.id} className="relative flex gap-3 pb-4 last:pb-0"><div className="flex flex-col items-center"><span className="mt-1 h-2 w-2 rounded-full bg-primary"/>{index < 4 && <span className="mt-1 w-px flex-1 bg-border"/>}</div><div><div className="text-xs font-semibold">{item.action} <span className="font-normal text-primary">by {item.agent}</span></div><p className="mt-1 text-[11px] leading-5 text-muted-foreground">{item.detail}</p></div></div>)}</div>
          </Panel>
        </section>
      </>}
    </PageShell>
  );
}

function Panel({ title, label, icon: Icon, action, className, children }: { title: string; label: string; icon: typeof Activity; action: string; className?: string; children: ReactNode }) {
  return <article className={cn("glass-card rounded-xl p-4 transition-colors hover:border-primary/25", className)}><header className="flex items-start justify-between gap-3"><div className="flex gap-3"><div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary/10 text-primary"><Icon className="h-4 w-4"/></div><div><h2 className="text-sm font-semibold">{title}</h2><p className="mt-0.5 text-[11px] text-muted-foreground">{label}</p></div></div><span className="rounded-md border border-border bg-secondary/60 px-2 py-1 font-mono text-[10px] uppercase text-muted-foreground">{action}</span></header>{children}</article>;
}
