import {
  createStartHandler,
  defaultStreamHandler,
} from "@tanstack/react-start/server";

import { getRouter } from "./router";
import "./start";

export default createStartHandler({
  createRouter: getRouter,
})(defaultStreamHandler);
